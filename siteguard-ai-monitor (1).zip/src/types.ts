
export interface Issue {
  id: string;
  type: 'critical' | 'warning' | 'info';
  category: string;
  title: string;
  description: string;
  detectedAt: string;
  aiAnalysis?: string;
  fixed?: boolean;
}

export interface Website {
  id: string;
  name: string;
  url: string;
  repo: string;
  framework: string;
  status: 'active' | 'error' | 'maintenance';
  lastScan: string | null;
  issues: Issue[];
  config: {
    githubToken?: string;
    scanInterval: number;
  };
}
