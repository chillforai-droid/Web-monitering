
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  Activity, 
  Menu,
  X,
  ChevronRight,
  Plus, 
  Trash2, 
  RefreshCw, 
  ArrowRight, 
  AlertCircle, 
  CheckCircle2, 
  Clock, 
  Search, 
  Github, 
  ExternalLink,
  ShieldCheck,
  Zap,
  BarChart3,
  Cpu,
  Terminal,
  Settings,
  BookOpen,
  FileText,
  Shield,
  Folder,
  ChefHat,
  FileCode,
  Loader2,
  Camera,
  Globe,
  Smartphone,
  Package
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Website, Issue } from './types';

import { createWorker } from 'tesseract.js';

export default function App() {
  const [websites, setWebsites] = useState<Website[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSite, setSelectedSite] = useState<Website | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [scanning, setScanning] = useState<string | null>(null);
  const [analyzing, setAnalyzing] = useState<string | null>(null);
  const [selectedIssueIds, setSelectedIssueIds] = useState<string[]>([]);
  const [fixing, setFixing] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'issues' | 'editor'>('issues');
  const [mainView, setMainView] = useState<'dashboard' | 'scans' | 'logs' | 'settings' | 'docs' | 'legal'>('dashboard');
  const [docLanguage, setDocLanguage] = useState<'en' | 'hi' | 'es'>('en');
  const [logs, setLogs] = useState<any[]>([]);
  const [repoFiles, setRepoFiles] = useState<any[]>([]);
  const [currentPath, setCurrentPath] = useState('');
  const [selectedFile, setSelectedFile] = useState<{path: string, content: string, sha: string} | null>(null);
  const [editInstruction, setEditInstruction] = useState('');
  const [globalInstruction, setGlobalInstruction] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [isGlobalEditing, setIsGlobalEditing] = useState(false);
  const [editingSite, setEditingSite] = useState<Website | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [toast, setToast] = useState<{message: string, type: 'success' | 'error'} | null>(null);
  const [aiModels, setAIModels] = useState<any[]>([]);
  const [selectedModelId, setSelectedModelId] = useState<string>('');
  const [autoPush, setAutoPush] = useState(true);
  const [aiPreview, setAIPreview] = useState<{path: string, content: string, sha?: string} | null>(null);
  const [projectPreview, setProjectPreview] = useState<any[] | null>(null);
  const [screenshotContext, setScreenshotContext] = useState<string | null>(null);
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [isVisionLoading, setIsVisionLoading] = useState(false);
  const [lastAnalysis, setLastAnalysis] = useState<{summary: string, error: string} | null>(null);
  const [userOpenRouterKey, setUserOpenRouterKey] = useState<string>(() => localStorage.getItem('user_openrouter_key') || '');

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setScreenshotPreview(URL.createObjectURL(file));
    setIsVisionLoading(true);
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      try {
        const worker = await createWorker('eng');
        const ret = await worker.recognize(base64);
        await worker.terminate();
        
        setScreenshotContext(ret.data.text);
      } catch (err: any) {
        console.error("OCR failed:", err.message);
      } finally {
        setIsVisionLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  useEffect(() => {
    fetchAIModels();
  }, []);

  const fetchAIModels = async () => {
    try {
      const res = await axios.get('/api/ai/models');
      setAIModels(res.data);
    } catch (err) {
      console.warn("Failed to fetch AI models", err);
    }
  };

  useEffect(() => {
    if (toast) {
      const timer = setTimeout(() => setToast(null), 3000);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  useEffect(() => {
    if (selectedSite && activeTab === 'editor') {
      fetchRepoFiles();
    }
  }, [selectedSite, activeTab, currentPath]);

  const fetchRepoFiles = async () => {
    if (!selectedSite) return;
    setRepoFiles([]); // Reset
    try {
      const res = await axios.get(`/api/github/files/${selectedSite.id}?path=${currentPath}`);
      setRepoFiles(res.data);
    } catch (err: any) {
      const msg = err.response?.data?.error || err.message;
      alert(`Failed to fetch files: ${msg}`);
      setActiveTab('issues'); // Fallback if file fetch fails
    }
  };

  const fetchFileContent = async (path: string) => {
    if (!selectedSite) return;
    try {
      const res = await axios.get(`/api/github/content/${selectedSite.id}?path=${path}`);
      setSelectedFile({ path, content: res.data.content, sha: res.data.sha });
    } catch (err) {
      alert("Failed to load file content");
    }
  };

  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showTerminal, setShowTerminal] = useState(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isEditing || isGlobalEditing || scanning) {
      setShowTerminal(true);
      interval = setInterval(() => {
        fetchLogs();
      }, 1000);
    } else {
      // Keep terminal open for a bit after completion if there were changes
    }
    return () => { if (interval) clearInterval(interval); };
  }, [isEditing, isGlobalEditing, scanning]);

  const fetchLogs = async () => {
    try {
      const logRes = await axios.get('/api/logs');
      setLogs(logRes.data);
    } catch (err) {
      console.warn("Log fetch failed");
    }
  };

  const handleAIEdit = async () => {
    if (!selectedSite || !selectedFile || !editInstruction) return;
    setIsEditing(true);
    try {
      const res = await axios.post('/api/ai/edit', {
        siteId: selectedSite.id,
        filePath: selectedFile.path,
        instruction: editInstruction,
        currentContent: selectedFile.content,
        sha: selectedFile.sha,
        modelId: selectedModelId,
        autoPush: autoPush,
        screenshotContext: screenshotContext,
        userApiKey: userOpenRouterKey
      });

      if (!autoPush) {
        setAIPreview({
          path: selectedFile.path,
          content: res.data.newContent,
          sha: selectedFile.sha
        });
        setLastAnalysis({ summary: res.data.summary, error: res.data.detectedError });
        setToast({ message: "AI has generated the code. Please review and confirm.", type: 'success' });
      } else {
        setLastAnalysis({ summary: res.data.summary, error: res.data.detectedError });
        setToast({ message: "AI Successfully updated the code on GitHub!", type: 'success' });
        setSelectedFile(null);
        setEditInstruction('');
      }
      setScreenshotContext(null); // Clear context after success
      setScreenshotPreview(null);
      fetchData();
    } catch (err: any) {
      setToast({ message: "AI Edit failed: " + (err.response?.data?.error || err.message), type: 'error' });
    } finally {
      setIsEditing(false);
    }
  };

  const handleGlobalProjectEdit = async () => {
    if (!selectedSite || !globalInstruction) return;
    setIsGlobalEditing(true);
    try {
      const res = await axios.post('/api/ai/project-edit', {
        siteId: selectedSite.id,
        instruction: globalInstruction,
        modelId: selectedModelId,
        autoPush: autoPush,
        userApiKey: userOpenRouterKey
      });

      if (!autoPush) {
        setProjectPreview(res.data.changes || []);
        setLastAnalysis({ summary: res.data.summary, error: res.data.detectedError });
        setToast({ message: `AI prepared ${res.data.changes?.length || 0} file updates. Review below.`, type: 'success' });
      } else {
        setLastAnalysis({ summary: res.data.summary, error: res.data.detectedError });
        setToast({ message: `Success! Branch ${res.data.branch} created with ${res.data.filesUpdated} file updates`, type: 'success' });
        setGlobalInstruction('');
      }
      fetchData();
    } catch (err: any) {
      setToast({ message: "Project-wide update failed: " + (err.response?.data?.error || err.message), type: 'error' });
    } finally {
      setIsGlobalEditing(false);
    }
  };

  const handleCommitPreview = async () => {
    if (!selectedSite || (!aiPreview && !projectPreview)) return;
    setIsEditing(true);
    try {
      if (aiPreview) {
        await axios.post('/api/ai/commit', {
          siteId: selectedSite.id,
          filePath: aiPreview.path,
          content: aiPreview.content,
          sha: aiPreview.sha,
          message: `✨ Manual Confirm: AI Edited ${aiPreview.path}`
        });
        setAIPreview(null);
        setSelectedFile(null);
        setEditInstruction('');
      } else if (projectPreview) {
        const res = await axios.post('/api/ai/commit-project', {
          siteId: selectedSite.id,
          changes: projectPreview,
          instruction: globalInstruction
        });
        setProjectPreview(null);
        setGlobalInstruction('');
        setToast({ message: `Success! Branch ${res.data.branch} created with ${projectPreview.length} updates`, type: 'success' });
      }
      setToast({ message: "Changes pushed to GitHub successfully!", type: 'success' });
      fetchData();
    } catch (err: any) {
      setToast({ message: `Commit Error: ${err.response?.data?.error || err.message}`, type: 'error' });
    } finally {
      setIsEditing(false);
    }
  };

  const criticalCount = websites.reduce((acc, site) => acc + site.issues.filter(i => i.type === 'critical').length, 0);
  const [siteForm, setSiteForm] = useState({
    name: '',
    url: '',
    repo: '',
    framework: 'React',
    githubToken: ''
  });

  const fetchData = async () => {
    try {
      const siteRes = await axios.get('/api/websites');
      setWebsites(siteRes.data);
      const logRes = await axios.get('/api/logs');
      setLogs(logRes.data);
    } catch (err) {
      console.error("Failed to fetch data", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSaveWebsite = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingSite) {
        const res = await axios.put(`/api/websites/${editingSite.id}`, siteForm);
        setWebsites(websites.map(w => w.id === editingSite.id ? res.data : w));
        setShowEditModal(false);
        setEditingSite(null);
        if (selectedSite?.id === editingSite.id) setSelectedSite(res.data);
      } else {
        const res = await axios.post('/api/websites', siteForm);
        setWebsites([...websites, res.data]);
        setShowAddModal(false);
      }
      setSiteForm({ name: '', url: '', repo: '', framework: 'React', githubToken: '' });
    } catch (err: any) {
      alert("Error saving website: " + (err.response?.data?.error || err.message));
    }
  };

  const openEditModal = (site: Website) => {
    setEditingSite(site);
    setSiteForm({
      name: site.name,
      url: site.url,
      repo: site.repo,
      framework: site.framework,
      githubToken: site.config.githubToken || ''
    });
    setShowEditModal(true);
  };

  const handleDeleteWebsite = async (id: string) => {
    try {
      await axios.delete(`/api/websites/${id}`);
      setWebsites(websites.filter(w => w.id !== id));
      if (selectedSite?.id === id) setSelectedSite(null);
      setDeleteConfirmId(null);
      setToast({ message: "Website removed successfully", type: 'success' });
    } catch (err) {
      setToast({ message: "Failed to remove website", type: 'error' });
    }
  };

  const openAddModal = () => {
    setEditingSite(null);
    setSiteForm({ name: '', url: '', repo: '', framework: 'React', githubToken: '' });
    setShowAddModal(true);
  };
   
  const handleScan = async (id: string) => {
    setScanning(id);
    try {
      const res = await axios.post(`/api/scan/${id}`);
      setWebsites(websites.map(w => w.id === id ? res.data : w));
      if (selectedSite?.id === id) setSelectedSite(res.data);
      setToast({ message: `Scan completed for ${res.data.name}`, type: 'success' });
      fetchData(); // Refresh logs
    } catch (err) {
      setToast({ message: "Scan failed", type: 'error' });
    } finally {
      setScanning(null);
    }
  };

  const handleAnalyze = async (siteId: string, issueId: string) => {
    setAnalyzing(issueId);
    try {
      const res = await axios.post(`/api/analyze/${siteId}/${issueId}`, {
        modelId: selectedModelId,
        screenshotContext: screenshotContext,
        userApiKey: userOpenRouterKey
      });
      // Refresh local state to show AI analysis
      setScreenshotContext(null); // Clear context after success
      setScreenshotPreview(null);
      await fetchData();
      if (selectedSite?.id === siteId) {
        const updated = (await axios.get('/api/websites')).data.find((s: any) => s.id === siteId);
        setSelectedSite(updated);
      }
    } catch (err: any) {
      alert(`AI Analysis failed: ${err.response?.data?.error || err.message}`);
    } finally {
      setAnalyzing(null);
    }
  };

  const handleFix = async (siteId: string, issueId: string) => {
    if (!selectedSite) return;
    const issue = selectedSite.issues.find(i => i.id === issueId);
    if (!issue) return;

    setActiveTab('editor');
    setEditInstruction(`Fix this issue: ${issue.title}\n\nDescription: ${issue.description}\n\nAnalysis:\n${issue.aiAnalysis || 'Analyze this issue and apply the fix to the source code.'}`);
    setToast({ 
      message: "Ready to fix in AI Editor. Please select the target file.", 
      type: 'success' 
    });
  };

  const handleBulkFix = () => {
    if (!selectedSite || selectedIssueIds.length === 0) return;
    
    const selectedIssues = selectedSite.issues.filter(i => selectedIssueIds.includes(i.id));
    const bulkPrompt = selectedIssues.map(i => `- ${i.title}: ${i.description}`).join('\n');
    
    setActiveTab('editor');
    setGlobalInstruction(`Perform a project-wide refactor to fix the following issues:\n\n${bulkPrompt}`);
    setToast({ 
      message: `Project-wide fix initiated for ${selectedIssueIds.length} issues.`, 
      type: 'success' 
    });
  };

  const toggleIssueSelection = (id: string) => {
    setSelectedIssueIds(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const selectAllIssues = () => {
    if (!selectedSite) return;
    if (selectedIssueIds.length === selectedSite.issues.length) {
      setSelectedIssueIds([]);
    } else {
      setSelectedIssueIds(selectedSite.issues.map(i => i.id));
    }
  };

  useEffect(() => {
    setSelectedIssueIds([]);
  }, [selectedSite?.id]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-indigo-500/30">
      {/* Sidebar Overlay */}
      <div className="flex h-screen overflow-hidden">
        
        {/* Sidebar Overlay (Mobile) */}
        <AnimatePresence>
          {isSidebarOpen && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSidebarOpen(false)}
              className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-[60] md:hidden"
            />
          )}
        </AnimatePresence>

        {/* Sidebar */}
        <aside className={`
          fixed inset-y-0 left-0 z-[70] w-64 border-r border-slate-800 bg-slate-900 flex flex-col transition-transform duration-300 md:relative md:translate-x-0 md:bg-slate-900/50
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'}
        `}>
          <div className="p-6 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                <ShieldCheck className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-lg tracking-tight">SiteGuard</h1>
                <p className="text-xs text-slate-500 font-mono">v1.2.0-beta</p>
              </div>
            </div>
            <button 
              onClick={() => setIsSidebarOpen(false)}
              className="p-2 hover:bg-slate-800 rounded-lg text-slate-500 md:hidden"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <nav className="flex-1 px-4 py-4 space-y-1">
            <button 
              onClick={() => { setMainView('dashboard'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${mainView === 'dashboard' ? 'bg-indigo-500/10 text-indigo-400' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              <BarChart3 className="w-4 h-4" /> Dashboard
            </button>
            <button 
              onClick={() => { setMainView('scans'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${mainView === 'scans' ? 'bg-indigo-500/10 text-indigo-400' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              <Zap className="w-4 h-4" /> Scans
            </button>
            <button 
              onClick={() => { setMainView('logs'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${mainView === 'logs' ? 'bg-indigo-500/10 text-indigo-400' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              <Terminal className="w-4 h-4" /> Logs
            </button>
            <button 
              onClick={() => { setMainView('settings'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${mainView === 'settings' ? 'bg-indigo-500/10 text-indigo-400' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              <Settings className="w-4 h-4" /> Settings
            </button>
            <button 
              onClick={() => { setMainView('docs'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${mainView === 'docs' ? 'bg-indigo-500/10 text-indigo-400' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              <BookOpen className="w-4 h-4" /> Docs
            </button>
            <button 
              onClick={() => { setMainView('legal'); setIsSidebarOpen(false); }}
              className={`w-full flex items-center gap-3 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${mainView === 'legal' ? 'bg-indigo-500/10 text-indigo-400' : 'text-slate-400 hover:bg-slate-800'}`}
            >
              <FileText className="w-4 h-4" /> Legal
            </button>
          </nav>

          <div className="p-4 border-t border-slate-800">
            <div className="bg-slate-800/50 rounded-lg p-3">
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold">API Status</span>
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
              </div>
              <p className="text-xs text-slate-300">OpenRouter Active</p>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-slate-950 to-slate-950">
          
          <header className="h-16 border-b border-slate-800/50 flex items-center justify-between px-4 md:px-8 sticky top-0 bg-slate-950/80 backdrop-blur-xl z-20">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setIsSidebarOpen(true)}
                className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 md:hidden"
              >
                <Menu className="w-5 h-5" />
              </button>
              <h2 className="text-sm font-medium text-slate-400 uppercase tracking-widest">{mainView}</h2>
            </div>
            <div className="flex items-center gap-4">
              <button 
                onClick={openAddModal}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm font-semibold inline-flex items-center gap-2 transition-all active:scale-95 shadow-lg shadow-indigo-600/20"
              >
                <Plus className="w-4 h-4" /> Add Website
              </button>
            </div>
          </header>

          <div className="p-4 md:p-8">
            {mainView === 'dashboard' ? (
              <>
                {/* Stats */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6 mb-8">
                  <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 md:p-6">
                    <p className="text-[10px] md:text-sm text-slate-500 mb-1">Monitored</p>
                    <h3 className="text-xl md:text-3xl font-bold">{websites.length}</h3>
                  </div>
                  <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 md:p-6">
                    <p className="text-[10px] md:text-sm text-slate-500 mb-1">Critical</p>
                    <h3 className={`text-xl md:text-3xl font-bold ${criticalCount > 0 ? 'text-rose-500' : 'text-emerald-500'}`}>
                      {criticalCount}
                    </h3>
                  </div>
                  <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 md:p-6">
                    <p className="text-[10px] md:text-sm text-slate-500 mb-1">Uptime</p>
                    <h3 className="text-xl md:text-3xl font-bold">99.8%</h3>
                  </div>
                  <div className="bg-slate-900/40 border border-slate-800 rounded-2xl p-4 md:p-6">
                    <p className="text-[10px] md:text-sm text-slate-500 mb-1">AI Fixes</p>
                    <h3 className="text-xl md:text-3xl font-bold text-indigo-400">
                      {websites.reduce((acc, s) => acc + s.issues.filter(i => i.aiAnalysis).length, 0)}
                    </h3>
                  </div>
                </div>

                {/* Content Area */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  {/* Website List */}
                  <div className={`lg:col-span-2 space-y-4 ${selectedSite ? 'hidden lg:block' : 'block'}`}>
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-4 gap-4">
                      <h3 className="text-lg font-bold">Your Websites</h3>
                      <div className="relative w-full md:w-auto">
                        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                        <input 
                          type="text" 
                          placeholder="Search sites..." 
                          className="bg-slate-900/50 border border-slate-800 rounded-full pl-10 pr-4 py-2 text-xs focus:ring-1 focus:ring-indigo-500 outline-none w-full md:w-64"
                        />
                      </div>
                    </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {websites.map((site) => (
                          <motion.div 
                            key={`dash-${site.id}`}
                            layoutId={`card-${site.id}`}
                            onClick={() => setSelectedSite(site)}
                            className={`group relative p-4 md:p-6 bg-slate-900/40 border ${selectedSite?.id === site.id ? 'border-indigo-500/50 bg-indigo-500/5' : 'border-slate-800'} rounded-2xl hover:border-slate-700 transition-all cursor-pointer`}
                          >
                          <div className="flex justify-between items-start mb-4">
                            <div className={`p-2 rounded-xl bg-slate-800 text-slate-400 group-hover:text-indigo-400 transition-colors`}>
                              <Activity className="w-5 h-5" />
                            </div>
                            <div className="flex gap-2">
                              <button 
                                onClick={(e) => { e.stopPropagation(); openEditModal(site); }}
                                className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-500 hover:text-slate-200 transition-colors"
                              >
                                <Settings className="w-4 h-4" />
                              </button>
                              <button 
                                onClick={(e) => { e.stopPropagation(); setDeleteConfirmId(site.id); }}
                                className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-500 hover:text-rose-500 transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                          <h4 className="font-bold text-lg mb-1">{site.name}</h4>
                          <p className="text-slate-500 text-xs mb-4 flex items-center gap-1">
                            <ExternalLink className="w-3 h-3" /> {site.url}
                          </p>
                          
                          <div className="flex items-center justify-between text-[11px] text-slate-500 border-t border-slate-800 pt-4">
                            <div className="flex items-center gap-1 lowercase">
                              <Clock className="w-3 h-3" /> 
                              {site.lastScan ? new Date(site.lastScan).toLocaleTimeString() : 'Never scanned'}
                            </div>
                            <button 
                              onClick={(e) => { e.stopPropagation(); handleScan(site.id); }}
                              className={`p-2 hover:bg-slate-800 rounded-lg transition-colors ${scanning === site.id ? 'animate-spin text-indigo-400' : ''}`}
                            >
                              <RefreshCw className="w-4 h-4" />
                            </button>
                          </div>
                        </motion.div>
                      ))}
                    </div>

                    {websites.length === 0 && !loading && (
                      <div className="bg-slate-900/20 border border-dashed border-slate-800 rounded-3xl p-12 text-center">
                        <div className="inline-flex p-4 bg-slate-900 rounded-full mb-4">
                          <Plus className="w-8 h-8 text-slate-700" />
                        </div>
                        <h4 className="text-xl font-bold mb-2">No websites yet</h4>
                        <p className="text-slate-500 text-sm mb-6">Start by connecting your first domain to monitor for bugs and AI analysis.</p>
                        <button 
                          onClick={openAddModal}
                          className="bg-slate-800 hover:bg-slate-700 px-6 py-3 rounded-xl font-bold"
                        >
                          Connect Domain
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Detail Panel */}
                  <div className={`lg:col-span-1 ${selectedSite ? 'block' : 'hidden lg:block'}`}>
                    {/* ... Existing selectedSite logic ... */}
                    <AnimatePresence mode="wait">
                      {selectedSite ? (
                        <motion.div 
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0, x: 20 }}
                          className="bg-slate-900/60 border border-slate-800 rounded-3xl overflow-hidden sticky top-24"
                        >
                          <div className="p-6 border-b border-slate-800 bg-slate-900/80">
                            <div className="flex items-center justify-between mb-4">
                              <div className="flex items-center gap-2">
                                <button 
                                  onClick={() => setSelectedSite(null)} 
                                  className="p-2 hover:bg-slate-800 rounded-lg text-indigo-400 lg:hidden"
                                >
                                  <ArrowRight className="w-5 h-5 rotate-180" />
                                </button>
                                <h3 className="font-bold text-xl uppercase tracking-tighter">Site Intel</h3>
                              </div>
                              <button onClick={() => setSelectedSite(null)} className="text-slate-500 hover:text-white hidden lg:block">
                                <Plus className="w-5 h-5 rotate-45" />
                              </button>
                            </div>
                            <div className="flex items-center gap-3 mb-6">
                               <div className="w-12 h-12 bg-slate-800 rounded-2xl flex items-center justify-center font-mono text-indigo-400 text-xl font-bold">
                                 {selectedSite.name[0]}
                               </div>
                               <div>
                                 <h4 className="font-bold text-lg leading-tight">{selectedSite.name}</h4>
                                 <p className="text-xs text-slate-500">{selectedSite.framework} / {selectedSite.repo}</p>
                               </div>
                            </div>

                            <div className="flex bg-slate-950/50 p-1 rounded-xl border border-slate-800 mb-4">
                              <button 
                                onClick={() => setActiveTab('issues')}
                                className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'issues' ? 'bg-slate-800 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                              >
                                Issues
                              </button>
                              <button 
                                onClick={() => { setActiveTab('editor'); setCurrentPath(''); setSelectedFile(null); }}
                                className={`flex-1 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${activeTab === 'editor' ? 'bg-slate-800 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
                              >
                                AI Editor
                              </button>
                            </div>

                            <div className="flex items-center justify-between px-1">
                              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest">Auto Push</label>
                              <button 
                                onClick={() => setAutoPush(!autoPush)}
                                className={`w-8 h-4 rounded-full transition-all relative ${autoPush ? 'bg-indigo-600' : 'bg-slate-800'}`}
                              >
                                <div className={`absolute top-0.5 w-3 h-3 rounded-full bg-white transition-all ${autoPush ? 'left-4.5' : 'left-0.5'}`} />
                              </button>
                            </div>

                            <div className="space-y-1">
                              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest block px-1">Visual Context (OCR)</label>
                              <div className="relative group">
                                <input 
                                  type="file" 
                                  accept="image/*" 
                                  onChange={handleImageUpload}
                                  className="absolute inset-0 opacity-0 cursor-pointer z-10"
                                />
                                <div className={`w-full border border-dashed border-slate-800 rounded-xl py-3 flex flex-col items-center justify-center transition-all ${screenshotPreview ? 'bg-indigo-500/10 border-indigo-500/50' : 'bg-slate-950 group-hover:border-slate-700'}`}>
                                  {isVisionLoading ? (
                                    <div className="flex flex-col items-center gap-1">
                                      <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
                                      <span className="text-[8px] font-bold text-indigo-400 uppercase tracking-tighter">Silent Extraction...</span>
                                    </div>
                                  ) : screenshotPreview ? (
                                    <div className="relative w-full h-20 px-2">
                                      <img src={screenshotPreview} alt="Preview" className="w-full h-full object-cover rounded-lg" />
                                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-lg">
                                        <RefreshCw className="w-5 h-5 text-white" />
                                      </div>
                                    </div>
                                  ) : (
                                    <>
                                      <Camera className="w-4 h-4 text-slate-600 mb-1 group-hover:text-slate-400" />
                                      <span className="text-[9px] font-bold text-slate-600 uppercase tracking-tighter group-hover:text-slate-400">Add Screenshot</span>
                                    </>
                                  )}
                                </div>
                              </div>
                              {screenshotPreview && (
                                <div className="mt-2 flex items-center justify-between px-1">
                                  <span className="text-[8px] text-slate-500 font-mono italic">Context stored internally</span>
                                  <button 
                                    onClick={() => { setScreenshotPreview(null); setScreenshotContext(null); }}
                                    className="text-[8px] font-black uppercase text-rose-500 hover:text-rose-400"
                                  >
                                    Remove
                                  </button>
                                </div>
                              )}
                            </div>

                            <div className="space-y-1">
                              <label className="text-[9px] font-black text-slate-500 uppercase tracking-widest block px-1">AI Processor</label>
                              <select 
                                value={selectedModelId}
                                onChange={(e) => setSelectedModelId(e.target.value)}
                                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-[10px] font-bold outline-none text-indigo-400 focus:border-indigo-500/50 truncate transition-all"
                              >
                                <option value="">Default (Gemini 2.0 Flash)</option>
                                {aiModels.map(m => (
                                  <option key={m.id} value={m.id}>{m.name}</option>
                                ))}
                              </select>
                            </div>
                          </div>

                          <div className="p-6 space-y-6">
                            {(aiPreview || projectPreview || lastAnalysis) && (
                              <div className="bg-indigo-500/10 border border-indigo-500/30 rounded-2xl p-4 space-y-3">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
                                    <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">
                                      {lastAnalysis ? 'Mission Report' : 'Changes Ready'}
                                    </span>
                                  </div>
                                  <button onClick={() => setLastAnalysis(null)} className="text-slate-500 hover:text-white">
                                    <Plus className="w-3 h-3 rotate-45" />
                                  </button>
                                </div>
                                
                                {lastAnalysis && (
                                  <div className="space-y-2 border-t border-indigo-500/20 pt-2">
                                    <div className="space-y-0.5">
                                      <span className="text-[8px] font-black uppercase text-indigo-500/60">Detected Issue</span>
                                      <p className="text-[11px] text-slate-300 font-medium leading-tight">{lastAnalysis.error}</p>
                                    </div>
                                    <div className="space-y-0.5">
                                      <span className="text-[8px] font-black uppercase text-emerald-500/60">Fix Implemented</span>
                                      <p className="text-[11px] text-slate-300 font-medium leading-tight">{lastAnalysis.summary}</p>
                                    </div>
                                  </div>
                                )}

                                {(aiPreview || projectPreview) && (
                                  <>
                                    <p className="text-[11px] text-slate-400 italic">Review the changes in the terminal or code view below before pushing.</p>
                                    <div className="flex gap-2">
                                      <button 
                                        onClick={handleCommitPreview}
                                        disabled={isEditing}
                                        className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white py-2 rounded-xl text-[10px] font-black uppercase tracking-widest disabled:opacity-50 transition-all flex items-center justify-center gap-2"
                                      >
                                        {isEditing ? <Loader2 className="w-3 h-3 animate-spin" /> : <Github className="w-3 h-3" />}
                                        Confirm & Push
                                      </button>
                                      <button 
                                        onClick={() => { setAIPreview(null); setProjectPreview(null); setLastAnalysis(null); }}
                                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-[10px] font-black uppercase tracking-widest"
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  </>
                                )}
                              </div>
                            )}
                            {activeTab === 'issues' ? (
                              <>
                                <div className="grid grid-cols-2 gap-4 px-1">
                                   <div className="bg-slate-800/50 p-4 rounded-2xl border border-slate-800">
                                     <p className="text-[10px] text-slate-500 uppercase font-black mb-1 tracking-tighter">Core Vitals</p>
                                     <div className="flex items-center gap-2">
                                       <div className={`w-2 h-2 rounded-full ${selectedSite.issues.length > 5 ? 'bg-rose-500' : 'bg-emerald-500'} animate-pulse`} />
                                       <p className="text-xl font-black text-white">{selectedSite.issues.length > 0 ? '78%' : '100%'}</p>
                                     </div>
                                   </div>
                                   <div className="bg-slate-800/50 p-4 rounded-2xl border border-rose-500/10">
                                     <p className="text-[10px] text-slate-500 uppercase font-black mb-1 tracking-tighter">Incident Count</p>
                                     <p className="text-xl font-black text-rose-500">{selectedSite.issues.length}</p>
                                   </div>
                                </div>

                                <div className="grid grid-cols-3 gap-2 py-2 px-1">
                                  {[
                                    { label: 'SEO', icon: Search, status: selectedSite.issues.some(i => i.category === 'SEO') ? 'fail' : 'pass' },
                                    { label: 'API', icon: Globe, status: selectedSite.issues.some(i => i.category === 'API') ? 'fail' : 'pass' },
                                    { label: 'Runtime', icon: Terminal, status: selectedSite.issues.some(i => i.category === 'Runtime') ? 'fail' : 'pass' },
                                    { label: 'Mobile', icon: Smartphone, status: selectedSite.issues.some(i => i.category === 'Mobile') ? 'fail' : 'pass' },
                                    { label: 'Build', icon: Package, status: selectedSite.issues.some(i => i.category === 'Build') ? 'fail' : 'pass' },
                                    { label: 'Perf', icon: Zap, status: selectedSite.issues.some(i => i.category === 'Performance') ? 'fail' : 'pass' }
                                  ].map((m, i) => (
                                    <div key={i} className="bg-slate-950/40 p-2 rounded-xl flex flex-col items-center justify-center border border-slate-800/50">
                                      <m.icon className={`w-3 h-3 mb-1 ${m.status === 'pass' ? 'text-emerald-500' : 'text-rose-500'}`} />
                                      <span className="text-[8px] font-black uppercase tracking-tighter text-slate-500">{m.label}</span>
                                    </div>
                                  ))}
                                </div>
                                <div className="space-y-4 pt-2">
                                  <div className="flex items-center justify-between px-1">
                                     <div className="flex items-center gap-2">
                                       <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Incident Log</h5>
                                       <button 
                                         onClick={selectAllIssues}
                                         className="text-[10px] font-bold text-indigo-400 hover:text-indigo-300 transition-colors"
                                       >
                                         {selectedIssueIds.length === (selectedSite?.issues.length || 0) ? 'Deselect All' : 'Select All'}
                                       </button>
                                       {selectedIssueIds.length > 0 && (
                                         <button 
                                           onClick={handleBulkFix}
                                           className="px-2 py-0.5 bg-indigo-600 hover:bg-indigo-500 text-[8px] font-black uppercase rounded text-white transition-all animate-pulse"
                                         >
                                           Resolve {selectedIssueIds.length} Issues
                                         </button>
                                       )}
                                     </div>
                                     <span className="text-[9px] text-slate-600 font-mono italic">Sorted by impact</span>
                                  </div>
                                  {selectedSite.issues.length > 0 ? (
                                    selectedSite.issues.map((issue, idx) => (
                                      <div 
                                        key={`issue-${issue.id}-${idx}`} 
                                        onClick={() => toggleIssueSelection(issue.id)}
                                        className={`bg-slate-950 border ${selectedIssueIds.includes(issue.id) ? 'border-indigo-500 bg-indigo-500/5 shadow-lg shadow-indigo-500/10' : 'border-slate-800/50'} hover:border-slate-700 rounded-2xl p-5 group transition-all cursor-pointer`}
                                      >
                                        <div className="flex items-start justify-between mb-2">
                                          <div className="flex items-center gap-2">
                                            <div className={`w-4 h-4 rounded border ${selectedIssueIds.includes(issue.id) ? 'bg-indigo-600 border-indigo-500' : 'border-slate-700'} flex items-center justify-center transition-all`}>
                                              {selectedIssueIds.includes(issue.id) && <CheckCircle2 className="w-3 h-3 text-white" />}
                                            </div>
                                            <div className={`w-2 h-2 rounded-full ${issue.type === 'critical' ? 'bg-rose-500' : 'bg-amber-500'}`} />
                                            <span className="text-xs font-black text-white">{issue.title}</span>
                                          </div>
                                          <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full border ${
                                            issue.type === 'critical' ? 'bg-rose-500/10 text-rose-500 border-rose-500/20' : 'bg-slate-800 text-slate-400 border-slate-700'
                                          }`}>
                                            {issue.category}
                                          </span>
                                        </div>
                                        <p className="text-[11px] text-slate-400 mb-5 leading-relaxed font-medium">{issue.description}</p>
                                        
                                        {issue.aiAnalysis ? (
                                          <div className="bg-emerald-500/5 border border-emerald-500/20 rounded-2xl p-4 mb-3">
                                            <div className="flex items-center gap-2 mb-3">
                                              <div className="p-1.5 bg-emerald-500/10 rounded-lg">
                                                <Cpu className="w-3 h-3 text-emerald-400" />
                                              </div>
                                              <span className="text-[10px] font-black text-emerald-400 uppercase tracking-widest text-[9px]">Verified Fix Script</span>
                                            </div>
                                            <div className="text-[11px] text-slate-300 font-mono whitespace-pre-wrap max-h-40 overflow-y-auto custom-scrollbar italic leading-tight p-2 bg-slate-950/50 rounded-xl border border-emerald-500/10">
                                              {issue.aiAnalysis}
                                            </div>
                                            <button 
                                              onClick={(e) => { e.stopPropagation(); handleFix(selectedSite.id, issue.id); }}
                                              disabled={fixing === issue.id}
                                              className="w-full mt-4 bg-emerald-600 hover:bg-emerald-500 text-white py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all active:scale-95 disabled:opacity-50"
                                            >
                                              {fixing === issue.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <ChevronRight className="w-3 h-3" />}
                                              {fixing === issue.id ? 'Loading...' : 'Execute Integration via AI'}
                                            </button>
                                          </div>
                                        ) : (
                                          <button 
                                            onClick={(e) => { e.stopPropagation(); handleAnalyze(selectedSite.id, issue.id); }}
                                            disabled={analyzing === issue.id}
                                            className="w-full bg-slate-900 border border-slate-800 hover:border-indigo-500/50 text-slate-300 hover:text-indigo-400 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                                          >
                                            {analyzing === issue.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3 group-hover:rotate-180 transition-transform duration-500" />}
                                            {analyzing === issue.id ? 'Analyzing Logic...' : 'Analyze & Suggest Fix'}
                                          </button>
                                        )}
                                      </div>
                                    ))
                                  ) : (
                                    <div className="bg-slate-950/50 border border-dashed border-slate-800 rounded-3xl py-12 flex flex-col items-center">
                                      <div className="p-4 bg-emerald-500/5 rounded-full mb-4">
                                        <CheckCircle2 className="w-8 h-8 text-emerald-500/40" />
                                      </div>
                                      <p className="text-[10px] font-black uppercase text-slate-500 tracking-widest">Environment Clean</p>
                                      <p className="text-[11px] text-slate-600 mt-1 italic">No active production threats detected.</p>
                                    </div>
                                  )}
                                </div>
                              </>
                            ) : (
                              <div className="space-y-4">
                                {!selectedFile ? (
                                  <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                      <h5 className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
                                        {currentPath ? `/${currentPath}` : 'Root Repository'}
                                      </h5>
                                      {currentPath && (
                                        <button 
                                          onClick={() => {
                                            const parts = currentPath.split('/');
                                            parts.pop();
                                            setCurrentPath(parts.join('/'));
                                          }}
                                          className="text-[10px] font-bold text-indigo-400 hover:underline"
                                        >
                                          Back Up
                                        </button>
                                      )}
                                    </div>

                                    <div className="grid gap-2 max-h-80 overflow-y-auto custom-scrollbar pr-2">
                                      {repoFiles.map((file, idx) => (
                                        <button 
                                          key={`file-${file.path}-${idx}`}
                                          onClick={() => {
                                            if (file.type === 'dir') {
                                              setCurrentPath(file.path);
                                            } else {
                                              fetchFileContent(file.path);
                                            }
                                          }}
                                          className="flex items-center gap-3 p-3 bg-slate-950/50 border border-slate-800 rounded-xl hover:border-indigo-500/50 text-left transition-all group"
                                        >
                                          <div className="flex items-center justify-center p-2 rounded-lg bg-slate-900 group-hover:bg-slate-800">
                                            {file.type === 'dir' ? (
                                              <Folder className="w-4 h-4 text-amber-500" />
                                            ) : (
                                              <Terminal className="w-4 h-4 text-slate-400 group-hover:text-indigo-400" />
                                            )}
                                          </div>
                                          <div className="flex-1 min-w-0">
                                            <p className="text-xs font-medium truncate">{file.name}</p>
                                            <p className="text-[9px] text-slate-600 uppercase">{file.type}</p>
                                          </div>
                                          <ArrowRight className="w-3 h-3 text-slate-700 opacity-0 group-hover:opacity-100 transition-all" />
                                        </button>
                                      ))}
                                      {repoFiles.length === 0 && <p className="text-center text-xs text-slate-600 py-4 italic">Empty directory</p>}
                                    </div>

                                    <div className="pt-4 border-t border-slate-800">
                                      <div className="flex items-center gap-2 mb-3">
                                        <ChefHat className="w-4 h-4 text-rose-500" />
                                        <h5 className="text-[10px] font-black text-rose-500/80 uppercase tracking-widest">Global AI Architect</h5>
                                      </div>
                                      <div className="bg-rose-500/5 border border-rose-500/20 rounded-2xl p-3 md:p-4">
                                        <p className="text-[10px] text-slate-500 mb-2 uppercase font-bold">Mass Refactoring Prompt</p>
                                        <textarea 
                                          value={globalInstruction}
                                          onChange={(e) => setGlobalInstruction(e.target.value)}
                                          placeholder="Example: Implement dark mode support across the entire project structure."
                                          className="w-full h-24 md:h-20 bg-slate-900/50 border border-slate-800 rounded-xl p-3 text-xs outline-none focus:border-rose-500/50 transition-all mb-3 resize-none"
                                        />
                                        <button 
                                          onClick={handleGlobalProjectEdit}
                                          disabled={isGlobalEditing || !globalInstruction}
                                          className="w-full bg-rose-600 hover:bg-rose-500 text-white py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all disabled:opacity-50 shadow-lg shadow-rose-600/20"
                                        >
                                          {isGlobalEditing ? 'Architecting...' : 'Deploy Global Changes'}
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                ) : (
                                  <div className="space-y-4">
                                    <div className="flex items-center justify-between">
                                      <div className="flex items-center gap-2">
                                        <button onClick={() => setSelectedFile(null)} className="text-slate-500 hover:text-white">
                                          <ArrowRight className="w-4 h-4 rotate-180" />
                                        </button>
                                        <span className="text-xs font-bold text-indigo-400">{selectedFile.path}</span>
                                      </div>
                                    </div>

                                    <div className="space-y-2">
                                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Instruction</label>
                                      <textarea 
                                        value={editInstruction}
                                        onChange={(e) => setEditInstruction(e.target.value)}
                                        placeholder="Examples: 
- Change background to dark blue
- Fix the login button alignment
- Add a contact form to the header"
                                        className="w-full h-32 bg-slate-950 border border-slate-800 rounded-2xl p-4 text-sm outline-none focus:border-indigo-500 transition-colors custom-scrollbar"
                                      />
                                    </div>

                                    <button 
                                      onClick={handleAIEdit}
                                      disabled={isEditing || !editInstruction}
                                      className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold py-3 rounded-xl flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/20"
                                    >
                                      {isEditing ? (
                                        <>
                                          <RefreshCw className="w-4 h-4 animate-spin" />
                                          AI is Updating...
                                        </>
                                      ) : (
                                        <>
                                          <Cpu className="w-4 h-4" />
                                          Apply AI Update
                                        </>
                                      )}
                                    </button>
                                    <p className="text-[9px] text-center text-slate-600 uppercase tracking-tighter">This will commit directly to the repository</p>
                                  </div>
                                )}
                              </div>
                            )}
                          </div>
                        </motion.div>
                      ) : (
                        <div className="h-[calc(100vh-200px)] flex flex-col items-center justify-center border border-dashed border-slate-800 rounded-3xl opacity-50">
                           <BarChart3 className="w-12 h-12 text-slate-800 mb-2" />
                           <p className="text-slate-600 text-xs font-bold uppercase tracking-widest">Select a portal to view telemetry</p>
                        </div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </>
            ) : mainView === 'logs' ? (
              <div className="max-w-4xl mx-auto space-y-4 px-4 md:px-0">
                <h3 className="text-2xl font-bold mb-6">System Event Logs</h3>
                {logs.map((log, idx) => (
                  <div key={`log-${log.id}-${idx}`} className="bg-slate-900/50 border border-slate-800 p-4 rounded-xl flex items-start gap-4">
                    <div className={`mt-1 w-2 h-2 rounded-full ${log.type === 'error' ? 'bg-rose-500' : log.type === 'warning' ? 'bg-amber-500' : log.type === 'success' ? 'bg-emerald-500' : 'bg-indigo-500'}`} />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{log.message}</p>
                      <p className="text-[10px] text-slate-500 uppercase mt-1">{new Date(log.timestamp).toLocaleString()}</p>
                    </div>
                  </div>
                ))}
                {logs.length === 0 && <p className="text-slate-500 text-center py-12">No event logs recorded yet.</p>}
              </div>
            ) : mainView === 'scans' ? (
              <div className="max-w-4xl mx-auto space-y-6 px-4 md:px-0">
                <h3 className="text-2xl font-bold">Scan Statistics</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {websites.map((site, idx) => (
                    <div key={`scan-${site.id}-${idx}`} className="bg-slate-900/50 border border-slate-800 p-6 rounded-2xl">
                      <div className="flex justify-between items-center mb-4">
                        <h4 className="font-bold">{site.name}</h4>
                        <button 
                          onClick={() => handleScan(site.id)}
                          className={`p-2 hover:bg-slate-800 rounded-lg ${scanning === site.id ? 'animate-spin' : ''}`}
                        >
                          <RefreshCw className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="space-y-2 text-sm text-slate-400">
                        <p className="flex justify-between"><span>Health</span> <span className="text-emerald-400">100%</span></p>
                        <p className="flex justify-between"><span>Last Scan</span> <span>{site.lastScan ? new Date(site.lastScan).toLocaleDateString() : 'Never'}</span></p>
                        <p className="flex justify-between"><span>Issues Found</span> <span className={site.issues.length > 0 ? 'text-rose-400' : ''}>{site.issues.length}</span></p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : mainView === 'docs' ? (
              <div className="max-w-4xl mx-auto pb-20 px-4 md:px-0">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 sticky top-16 bg-slate-950/80 backdrop-blur-md py-4 z-10 border-b border-slate-800/50 gap-4">
                  <div className="flex items-center gap-4">
                    <BookOpen className="w-8 h-8 text-indigo-500" />
                    <div>
                      <h3 className="text-2xl font-bold">Documentation</h3>
                      <p className="text-xs text-slate-500 font-mono tracking-widest uppercase">Mastering SiteGuard x AI</p>
                    </div>
                  </div>
                  <div className="flex bg-slate-900 rounded-lg p-1 border border-slate-800">
                    <button 
                      onClick={() => setDocLanguage('en')}
                      className={`px-3 py-1.5 text-[10px] font-black uppercase rounded-md transition-all ${docLanguage === 'en' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}
                    >
                      EN
                    </button>
                    <button 
                      onClick={() => setDocLanguage('hi')}
                      className={`px-3 py-1.5 text-[10px] font-black uppercase rounded-md transition-all ${docLanguage === 'hi' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20' : 'text-slate-500 hover:text-slate-300'}`}
                    >
                      HI
                    </button>
                  </div>
                </div>

                <div className="prose prose-invert max-w-none space-y-12">
                  {docLanguage === 'en' ? (
                    <article className="space-y-16 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24 text-slate-300">
                      <header className="space-y-8">
                        <div className="inline-block px-4 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full shadow-lg shadow-indigo-500/5">
                          <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">Master Technical manual v2.0.4</span>
                        </div>
                        <h1 className="text-6xl md:text-9xl font-black italic tracking-tighter text-white leading-[0.85] uppercase text-start md:text-left">
                          The <span className="text-indigo-500">SiteGuard</span><br/>Infrastructure
                        </h1>
                        <p className="text-slate-400 leading-relaxed text-2xl max-w-3xl font-light">
                          Welcome to the definitive source of truth for SiteGuard. This document serves as a high-level architectural overview and a granular step-by-step guide for developers.
                        </p>
                      </header>

                      <hr className="border-slate-800" />

                      {/* Section 01: The Vision */}
                      <section className="space-y-8">
                        <div className="flex items-center gap-4">
                          <div className="h-0.5 flex-1 bg-gradient-to-r from-indigo-500 to-transparent"></div>
                          <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Section 01</span>
                        </div>
                        <h2 className="text-4xl font-black text-white italic tracking-tight">The Vision: Closing the Security Gap</h2>
                        <div className="space-y-6 text-lg leading-relaxed text-justify">
                          <p>
                            In the rapidly evolving landscape of cybersecurity, the greatest threat is not the vulnerability itself, but the <strong>time-to-remediation</strong>. Most organizations identify critical flaws within hours but take days or even weeks to deploy a patch. This latency is where breaches happen.
                          </p>
                          <p>
                            <strong>SiteGuard</strong> was engineered to compress this timeline to zero. By integrating real-time telemetry, semantic repository mapping, and generative AI reasoning, we have created an autonomous safety loop. Our mission is to transform developers from "bug hunters" into "security orchestrators."
                          </p>
                          <p>
                            SiteGuard's core innovation lies in its ability to understand **semantic intent**. Instead of treating code as dead text, our AI engine treats it as a living system. It understands that a change in a database schema requires a corresponding change in the API validation logic. This level of holistic reasoning is what separates us from traditional static analysis tools.
                          </p>
                        </div>
                      </section>

                      {/* Section 02: Core Components */}
                      <section className="space-y-12">
                        <div className="flex items-center gap-4">
                          <div className="h-0.5 flex-1 bg-gradient-to-r from-emerald-500 to-transparent"></div>
                          <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">Section 02</span>
                        </div>
                        <h2 className="text-4xl font-black text-white italic tracking-tight">System Architecture Deep-Dive</h2>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="bg-slate-900 shadow-2xl border border-slate-800 p-10 rounded-[2.5rem] space-y-6 transform hover:-translate-y-2 transition-transform">
                            <div className="w-16 h-16 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                              <Cpu className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-2xl font-black text-white">1. The Neural Bridge</h3>
                            <p className="text-slate-400 text-sm leading-relaxed text-justify">
                              This component handles all third-party integrations. It securely manages your GitHub Personal Access Tokens (PAT) and OpenRouter keys using encrypted transient memory. It ensures that the AI has the "Context Window" it needs without ever compromising your data privacy.
                            </p>
                            <p className="text-slate-500 text-xs text-justify">
                              The Neural Bridge acts as a protocol buffer, translating complex GitHub API responses into a normalized format that the AI Orchestrator can ingest. It handles rate-limiting, retry logic, and secure credential handling.
                            </p>
                            <ul className="text-[10px] space-y-2 text-slate-500 uppercase font-bold tracking-widest">
                              <li className="flex items-center gap-2"><div className="w-1 h-1 bg-indigo-500 rounded-full" /> AES-256 Token Encryption</li>
                              <li className="flex items-center gap-2"><div className="w-1 h-1 bg-indigo-500 rounded-full" /> Stateless Session Management</li>
                              <li className="flex items-center gap-2"><div className="w-1 h-1 bg-indigo-500 rounded-full" /> Multi-Region High Availability</li>
                            </ul>
                          </div>

                          <div className="bg-slate-900 shadow-2xl border border-slate-800 p-10 rounded-[2.5rem] space-y-6 transform hover:-translate-y-2 transition-transform">
                            <div className="w-16 h-16 bg-emerald-600 rounded-3xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                              <ShieldCheck className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-2xl font-black text-white">2. Semantic Mapper</h3>
                            <p className="text-slate-400 text-sm leading-relaxed text-justify">
                              Unlike generic AI tools, SiteGuard understands your repository's structure. It performs a recursive scan of your directory tree to build a dependency graph. This allows the AI to understand how a vulnerability in <code>auth.ts</code> might affect <code>server.ts</code>.
                            </p>
                            <p className="text-slate-500 text-xs text-justify">
                              By mapping "Entry Points" and "Data Sinks," the Semantic Mapper can pinpoint where unsanitized data enters your system and exactly which lines of code allow it to reach a dangerous execution point.
                            </p>
                            <ul className="text-[10px] space-y-2 text-slate-500 uppercase font-bold tracking-widest">
                              <li className="flex items-center gap-2"><div className="w-1 h-1 bg-emerald-500 rounded-full" /> Recursive Dependency Tree</li>
                              <li className="flex items-center gap-2"><div className="w-1 h-1 bg-emerald-500 rounded-full" /> Static Code Analysis (SCA)</li>
                              <li className="flex items-center gap-2"><div className="w-1 h-1 bg-emerald-500 rounded-full" /> Impact Radius Prediction</li>
                            </ul>
                          </div>
                        </div>
                      </section>

                      {/* Section 03: Deployment & Setup */}
                      <section className="space-y-12">
                        <div className="flex items-center gap-4">
                          <div className="h-0.5 flex-1 bg-gradient-to-r from-amber-500 to-transparent"></div>
                          <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">Section 03</span>
                        </div>
                        <h2 className="text-4xl font-black text-white italic tracking-tight">Execution: The 7-Step Deployment</h2>
                        
                        <div className="space-y-12">
                          {[
                            { step: '01', title: 'Identity Bootstrapping', desc: 'Navigate to your GitHub account settings and generate a Personal Access Token with "repo," "workflow," and "write:packages" scopes. This token acts as the virtual hand of SiteGuard, allowing it to create branches and fix issues on your behalf.' },
                            { step: '02', title: 'Portal Ingress', desc: 'Add a new website to your dashboard. You will need to provide the physical URL of the site for uptime monitoring and the exact GitHub handle (e.g., owner/repository). SiteGuard verifies the connection using a high-speed handshake.' },
                            { step: '03', title: 'Intelligence Calibration', desc: 'While we provide a base-level model, for complex architectural refactoring, we recommend adding an OpenRouter API key. This gives SiteGuard access to large context models like Claude 3.5 or Gemini 1.5 Pro, which are essential for multi-file troubleshooting.' },
                            { step: '04', title: 'Anomaly Discovery', desc: 'Initiate a "Deep Scan." Our AI will crawl your repository, flagging security risks such as hardcoded secrets, package vulnerabilities, or improper input sanitization. Each issue is categorized by its "Blast Radius."' },
                            { step: '05', title: 'Surgical Remediation', desc: 'For specific bugs, use the "Integrate via AI Editor" tool. This ports the semantic analysis into a specialized coding interface where you can select the target file and have the AI generate a precise, localized patch.' },
                            { step: '06', title: 'Global Refactoring', desc: 'Use the Global Architect view for broad changes. For example, you can instruct the AI to "Implement CSRF protection across all forms in the project." The AI will then identify every relevant file and apply the change uniformly.' },
                            { step: '07', title: 'Shadow Integration', desc: 'All changes are pushed to an isolated "Shadow Branch" on GitHub. Review the changes, run your own CI tests, and merge the branch into your main code when you are 100% satisfied with the outcome.' }
                          ].map((item, index) => (
                            <div key={index} className="flex gap-8 group">
                              <div className="flex-none text-8xl font-black italic text-slate-900 group-hover:text-indigo-600 transition-colors duration-500 leading-none">{item.step}</div>
                              <div className="space-y-4 pt-4">
                                <h4 className="text-2xl font-bold text-white uppercase tracking-tighter">{item.title}</h4>
                                <p className="text-slate-500 text-lg leading-relaxed text-justify">{item.desc}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </section>

                      {/* Section 04: Advanced AI Logic */}
                      <section className="space-y-8 bg-indigo-600/5 border border-indigo-500/20 p-12 md:p-20 rounded-[4rem] relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2"></div>
                        <h2 className="text-5xl font-black text-white italic tracking-tight mb-8">IV. Advanced Intelligence Framework</h2>
                        <div className="space-y-8 relative z-10 text-xl leading-relaxed">
                          <p className="text-justify text-slate-300">
                            To master SiteGuard, one must move beyond the surface-level UI and understand the <strong>Cognitive Architecture</strong> that drives our decision-making engine. We do not simply "search and replace"; we "reason and refactor."
                          </p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                            <div className="space-y-6">
                              <h4 className="text-xl font-bold text-white flex items-center gap-3">
                                <Terminal className="w-5 h-5 text-indigo-400" />
                                1. Context Window management
                              </h4>
                              <p className="text-sm text-slate-400 leading-relaxed text-justify">
                                Our "Neural Bridge" uses a technique called <strong>Contextual Chunking</strong>. Instead of uploading your entire 50,000 line project to the AI, we parse the AST (Abstract Syntax Tree) to identify only the relevant imports and dependent modules. This allows models like Gemini 1.5 Pro to operate within their optimal performance curve, ensuring that the "Execute Integration" produces logically consistent code that doesn't break external dependencies.
                              </p>
                            </div>
                            
                            <div className="space-y-6">
                              <h4 className="text-xl font-bold text-white flex items-center gap-3">
                                <Zap className="w-5 h-5 text-amber-400" />
                                2. Zero-Shot Security Analysis
                              </h4>
                              <p className="text-sm text-slate-400 leading-relaxed text-justify">
                                SiteGuard's scanner is not just looking for regex patterns. It utilizes <strong>Prompt-Based Heuristics</strong>. We ask the model to "Think like a Red Team actor" as it traverses your file paths. It looks for logical race conditions, inconsistent session handling, and subtle type-coercion vulnerabilities that traditional tools like SonarQube or Snyk might miss due to their static nature.
                              </p>
                            </div>
                          </div>

                          <div className="pt-12 border-t border-indigo-500/10">
                            <h3 className="text-3xl font-black text-white italic mb-6">The Global Architect Approach</h3>
                            <p className="text-lg text-slate-400 leading-relaxed text-justify mb-8">
                              When you initiate a "Bulk Fix," the <strong>Global Architect</strong> takes command. It doesn't fix one issue at a time. Instead, it creates a <strong>Dependency Plan</strong>. 
                            </p>
                            <div className="bg-slate-950 p-8 rounded-3xl border border-slate-800 space-y-4">
                              <p className="text-xs font-mono text-indigo-300 mb-2 uppercase tracking-widest">Architectural Execution Log:</p>
                              <div className="space-y-2 font-mono text-[11px] text-slate-500">
                                <p className="flex gap-2"><span className="text-indigo-500">[01]</span> Mapping cross-file dependency graph for auth-middleware.ts...</p>
                                <p className="flex gap-2"><span className="text-indigo-500">[02]</span> Identifying data sinks in user-controller.ts and profile-api.ts...</p>
                                <p className="flex gap-2"><span className="text-indigo-500">[03]</span> Designing unified JWT rotation strategy across 4 affected modules...</p>
                                <p className="flex gap-2"><span className="text-emerald-500">[✔]</span> Dependency Plan Validated. Ready for Shadow Integration.</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </section>

                      {/* Section 05: Ethics, Privacy & Compliance */}
                      <section className="space-y-12">
                        <div className="flex items-center gap-4">
                          <div className="h-0.5 flex-1 bg-gradient-to-r from-rose-500 to-transparent"></div>
                          <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Section 05</span>
                        </div>
                        <h2 className="text-4xl font-black text-white italic tracking-tight uppercase">V. Trust, Ethics & Data Sovereignty</h2>
                        
                        <div className="space-y-8 text-lg leading-relaxed text-justify text-slate-400">
                          <p>
                            At the core of SiteGuard is a redundant commitment to <strong>Privacy-First AI</strong>. We understand that your source code is your organization's most valuable intellectual property. Our system was designed from the ground up to minimize data exposure.
                          </p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                            <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
                              <div className="w-12 h-12 bg-rose-500/10 rounded-2xl flex items-center justify-center">
                                <Shield className="w-6 h-6 text-rose-500" />
                              </div>
                              <h5 className="font-bold text-white uppercase">No Data Persistence</h5>
                              <p className="text-xs text-slate-500 leading-relaxed">Your code is ingested transiently into the AI inference engine. We do not store, cache, or use your private repository data for fine-tuning our global models.</p>
                            </div>
                            
                            <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
                              <div className="w-12 h-12 bg-indigo-500/10 rounded-2xl flex items-center justify-center">
                                <Settings className="w-6 h-6 text-indigo-500" />
                              </div>
                              <h5 className="font-bold text-white uppercase">User-Owned Keys</h5>
                              <p className="text-xs text-slate-500 leading-relaxed">By allowing users to provide their own OpenRouter keys, we ensure that you remain the "Billable Owner" and maintain full control over the AI traffic and logging policies.</p>
                            </div>

                            <div className="p-8 bg-slate-900 border border-slate-800 rounded-3xl space-y-4">
                              <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center">
                                <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                              </div>
                              <h5 className="font-bold text-white uppercase">Human-In-The-Loop</h5>
                              <p className="text-xs text-slate-500 leading-relaxed">Shadow Branches ensure that no machine-generated code ever reaches production without a human review and a GitHub Pull Request approval.</p>
                            </div>
                          </div>
                        </div>
                      </section>

                      {/* Section 06: Future Roadmap */}
                      <section className="space-y-8">
                        <h2 className="text-4xl font-black text-white italic tracking-tight uppercase">VI. The Horizon: SiteGuard v4</h2>
                        <p className="text-lg text-slate-400 leading-relaxed text-justify">
                          We are currently developing <strong>Predictive Security Pulse</strong>. This feature will predict where vulnerabilities are likely to occur before a single line of code is written, by analyzing the "Jitters" in your developer tickets and documentation.
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-6 bg-slate-900/40 border border-indigo-500/10 rounded-2xl">
                            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Q3 2026</span>
                            <h6 className="font-bold text-white mt-1">Multi-Repo Logic Sync</h6>
                          </div>
                          <div className="p-6 bg-slate-900/40 border border-indigo-500/10 rounded-2xl">
                            <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">Q4 2026</span>
                            <h6 className="font-bold text-white mt-1">Autonomous Dependency Patching</h6>
                          </div>
                        </div>
                      </section>

                      {/* Section 05: Troubleshooting */}
                      <section className="space-y-8">
                        <h2 className="text-4xl font-black text-white italic tracking-tight">V. Troubleshooting & Error States</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="p-8 bg-slate-900/50 border border-slate-800 rounded-3xl">
                            <h4 className="font-bold text-white mb-4">"Repository Not Found"</h4>
                            <p className="text-sm text-slate-400 leading-relaxed">Ensure your PAT has the correct scopes. If the repository is private, you must grant the token <code>full control of private repositories</code>. Also, check for typos in the <code>owner/name</code> format.</p>
                          </div>
                          <div className="p-8 bg-slate-900/50 border border-slate-800 rounded-3xl">
                            <h4 className="font-bold text-white mb-4">"AI Context Exhausted"</h4>
                            <p className="text-sm text-slate-400 leading-relaxed">For projects with thousands of files, the AI might hit a context limit. Use the surgical editor instead of the global architect to focus the AI on a specific subset of files.</p>
                          </div>
                        </div>
                      </section>

                      <footer className="pt-24 text-center space-y-4">
                        <div className="w-20 h-0.5 bg-slate-800 mx-auto"></div>
                        <p className="text-slate-600 text-[10px] font-mono tracking-widest uppercase">
                          Authorized Documentation | SiteGuard Security v1.2.0-beta Operations manual
                        </p>
                      </footer>
                    </article>
                  ) : (
                    <article className="space-y-16 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-24 text-slate-300">
                      <header className="space-y-8">
                        <div className="inline-block px-4 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full shadow-lg shadow-indigo-500/5">
                          <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">मास्टर तकनीकी नियमावली v2.0.4</span>
                        </div>
                        <h1 className="text-6xl md:text-9xl font-black italic tracking-tighter text-white leading-[0.85] uppercase text-start md:text-left">
                          साइटगार्ड <span className="text-indigo-500">इन्फ्रास्ट्रक्चर</span>
                        </h1>
                        <p className="text-slate-400 leading-relaxed text-2xl max-w-3xl font-light">
                          साइटगार्ड के लिए सत्य के निश्चित स्रोत में आपका स्वागत है। यह दस्तावेज़ डेवलपर्स के लिए एक उच्च-स्तरीय वास्तुकला अवलोकन और विस्तृत मार्गदर्शिका के रूप में कार्य करता है।
                        </p>
                      </header>

                      <hr className="border-slate-800" />

                      {/* Section 01: The Vision */}
                      <section className="space-y-8">
                        <div className="flex items-center gap-4">
                          <div className="h-0.5 flex-1 bg-gradient-to-r from-indigo-500 to-transparent"></div>
                          <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">अनुभाग 01</span>
                        </div>
                        <h2 className="text-4xl font-black text-white italic tracking-tight">विजन: सुरक्षा अंतराल को बंद करना</h2>
                        <div className="space-y-6 text-lg leading-relaxed text-justify">
                          <p>
                            साइबर सुरक्षा के तेजी से बदलते परिदृश्य में, सबसे बड़ा खतरा स्वयं भेद्यता (vulnerability) नहीं है, बल्कि **सुधार का समय** है। अधिकांश संगठन घंटों के भीतर महत्वपूर्ण खामियों की पहचान कर लेते हैं लेकिन पैच तैनात करने में दिनों या हफ्तों का समय लेते हैं। यही वह समय है जहां सुरक्षा का उल्लंघन (breach) होता है।
                          </p>
                          <p>
                            **साइटगार्ड** को इस समयरेखा को शून्य पर लाने के लिए इंजीनियर किया गया है। रीयल-टाइम टेलीमेट्री, सिमेंटिक रिपॉजिटरी मैपिंग और जेनरेटिव एआई का उपयोग करके, हमने एक स्वायत्त सुरक्षा लूप बनाया है। हमारा मिशन डेवलपर्स को "बग हंटर्स" से "सिक्योरिटी ऑर्केस्ट्रेटर" में बदलना है।
                          </p>
                          <p>
                            साइटगार्ड का मुख्य नवाचार इसकी **सिमेंटिक इरादे (semantic intent)** को समझने की क्षमता में निहित है। हमारा एआई इंजन कोड को केवल टेक्स्ट की तरह नहीं, बल्कि एक जीवित सिस्टम की तरह देखता है। यह समझता है कि अगर डेटाबेस स्कीमा में बदलाव होता है, तो एपीआई वैलिडेशन लॉजिक में भी बदलाव की आवश्यकता है।
                          </p>
                        </div>
                      </section>

                      {/* Section 02: Core Components */}
                      <section className="space-y-12">
                        <div className="flex items-center gap-4">
                          <div className="h-0.5 flex-1 bg-gradient-to-r from-emerald-500 to-transparent"></div>
                          <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">अनुभाग 02</span>
                        </div>
                        <h2 className="text-4xl font-black text-white italic tracking-tight">सिस्टम वास्तुकला का गहराई से विश्लेषण</h2>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                          <div className="bg-slate-900 shadow-2xl border border-slate-800 p-10 rounded-[2.5rem] space-y-6">
                            <div className="w-16 h-16 bg-indigo-600 rounded-3xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
                              <Cpu className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-2xl font-black text-white">1. न्यूरल ब्रिज (Neural Bridge)</h3>
                            <p className="text-slate-400 text-sm leading-relaxed text-justify">
                              यह घटक सभी थर्ड-पार्टी इंटीग्रेशन को संभालता है। यह आपके गिटहब पर्सनल एक्सेस टोकन (PAT) और ओपनराउटर कुंजियों को सुरक्षित रूप से प्रबंधित करता है। यह सुनिश्चित करता है कि आपकी गोपनीयता से समझौता किए बिना एआई के पास जरूरी डेटा हो।
                            </p>
                            <ul className="text-[10px] space-y-2 text-slate-500 uppercase font-bold tracking-widest">
                              <li className="flex items-center gap-2"><div className="w-1 h-1 bg-indigo-500 rounded-full" /> AES-256 टोकन एन्क्रिप्शन</li>
                              <li className="flex items-center gap-2"><div className="w-1 h-1 bg-indigo-500 rounded-full" /> स्टेटलेस सेशन मैनेजमेंट</li>
                            </ul>
                          </div>

                          <div className="bg-slate-900 shadow-2xl border border-slate-800 p-10 rounded-[2.5rem] space-y-6">
                            <div className="w-16 h-16 bg-emerald-600 rounded-3xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
                              <ShieldCheck className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-2xl font-black text-white">2. सिमेंटिक मैपर (Semantic Mapper)</h3>
                            <p className="text-slate-400 text-sm leading-relaxed text-justify">
                              सामान्य एआई टूल के विपरीत, साइटगार्ड आपकी रिपॉजिटरी की संरचना को समझता है। यह फाइलों के बीच के संबंधों को जानने के लिए एक 'डिपेंडेंसी ग्राफ' बनाता है, जिससे एआई को सटीक सुधार करने में मदद मिलती है।
                            </p>
                            <ul className="text-[10px] space-y-2 text-slate-500 uppercase font-bold tracking-widest">
                               <li className="flex items-center gap-2"><div className="w-1 h-1 bg-emerald-500 rounded-full" /> रिकर्सिव डिपेंडेंसी ट्री</li>
                               <li className="flex items-center gap-2"><div className="w-1 h-1 bg-emerald-500 rounded-full" /> स्टैटिक कोड विश्लेषण (SCA)</li>
                            </ul>
                          </div>
                        </div>
                      </section>

                      {/* Section 03: Deployment & Setup */}
                      <section className="space-y-12">
                        <div className="flex items-center gap-4">
                          <div className="h-0.5 flex-1 bg-gradient-to-r from-amber-500 to-transparent"></div>
                          <span className="text-[10px] font-black text-amber-500 uppercase tracking-widest">अनुभाग 03</span>
                        </div>
                        <h2 className="text-4xl font-black text-white italic tracking-tight">निष्पादन: 7-चरणीय सेटअप</h2>
                        
                        <div className="space-y-12">
                          {[
                            { step: '01', title: 'पहचान का प्रमाणीकरण', desc: 'गिटहब गिटहब सेटिंग्स में जाकर एक "Personal Access Token" बनाएं जिसमें "repo" और "workflow" स्कोप हों।' },
                            { step: '02', title: 'पोर्टल पंजीकरण', desc: 'अपने डैशबोर्ड में नई वेबसाइट जोड़ें। साइट का लाइव URL और गिटहब रिपॉजिटरी का लिंक (owner/repo) प्रदान करें।' },
                            { step: '03', title: 'एआई कैलिब्रेशन', desc: 'जटिल प्रोजेक्ट्स के लिए सेटिंग्स में ओपनराउटर (OpenRouter) एपीआई कुंजी जोड़ें ताकि शक्तिशाली मॉडल का उपयोग किया जा सके।' },
                            { step: '04', title: 'असंगति की खोज', desc: 'एक "Deep Scan" शुरू करें। हमारा एआई आपकी रिपॉजिटरी को स्कैन कर सुरक्षा जोखिमों की पहचान करेगा।' },
                            { step: '05', title: 'सटीक सुधार (Remediation)', desc: 'विशेष बग्स के लिए "Integrate via AI Editor" टूल का उपयोग करें जो सटीक बदलाव करने में माहिर है।' },
                            { step: '06', title: 'वैश्विक रिफैक्टरिंग', desc: 'पूरे प्रोजेक्ट में बड़े बदलाव करने के लिए "Global AI Architect" का उपयोग करें।' },
                            { step: '07', title: 'शैडो इंटीग्रेशन', desc: 'एआई द्वारा किए गए बदलावों को गिटहब पर "Shadow Branch" में देखें और संतुष्ट होने पर मर्ज करें।' }
                          ].map((item, index) => (
                            <div key={index} className="flex gap-8 group">
                              <div className="flex-none text-8xl font-black italic text-slate-900 group-hover:text-indigo-600 transition-colors leading-none">{item.step}</div>
                              <div className="space-y-4 pt-4">
                                <h4 className="text-2xl font-bold text-white uppercase tracking-tighter">{item.title}</h4>
                                <p className="text-slate-500 text-lg leading-relaxed text-justify">{item.desc}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </section>

                      {/* Section 04: Advanced AI Logic */}
                      <section className="space-y-8 bg-indigo-600/5 border border-indigo-500/20 p-12 md:p-20 rounded-[4rem] relative overflow-hidden">
                        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2"></div>
                        <h2 className="text-5xl font-black text-white italic tracking-tight mb-8 uppercase">IV. उन्नत इंटेलिजेंस फ्रेमवर्क</h2>
                        <div className="space-y-8 relative z-10 text-xl leading-relaxed">
                          <p className="text-justify text-slate-300">
                             साइटगार्ड के पूर्ण सामर्थ्य को समझने के लिए आपको इसके **संज्ञानात्मक ढांचे (Cognitive Framework)** की गहराईयों को जानना होगा। जैसा कि पहले उल्लेख किया गया है, यह इंजन केवल कोड सुधारक (code fixer) नहीं है, बल्कि एक **वास्तुशिल्प रणनीतिकार (Architectural Strategist)** है।
                          </p>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                            <div className="space-y-6">
                              <h4 className="text-xl font-bold text-white flex items-center gap-3">
                                <Terminal className="w-5 h-5 text-indigo-400" />
                                1. डायनामिक कॉन्टेक्स्ट टोकनाइजेशन
                              </h4>
                              <p className="text-sm text-slate-400 leading-relaxed text-justify">
                                हमारा न्यूरल ब्रिज केवल प्रासंगिक फाइलों को चुनता है। यह **लेक्सिकल स्कोपिंग और स्टेटिक एनालिसिस** का उपयोग करके यह निर्धारित करता है कि किसी दिए गए बग के लिए कौन से डेटा सोर्स और सिंक (sinks) महत्वपूर्ण हैं। यह एआई को भ्रमित होने से रोकता है और टोकन की बर्बादी को कम करता है।
                              </p>
                            </div>
                            
                            <div className="space-y-6">
                              <h4 className="text-xl font-bold text-white flex items-center gap-3">
                                <Zap className="w-5 h-5 text-amber-400" />
                                2. प्रेडिक्टिव इंपैक्ट मैपिंग
                              </h4>
                              <p className="text-sm text-slate-400 leading-relaxed text-justify">
                                जब भी एआई कोई बदलाव सुझाता है, साइटगार्ड उसके **प्रभाव क्षेत्र (Impact Radius)** की भविष्यवाणी करता है। यदि कोई बदलाव आपके प्रमाणीकरण प्रवाह (authentication flow) को बाधित कर सकता है, तो सिस्टम आपको चेतावनी देगा और वैकल्पिक सुधार सुझाएगा।
                              </p>
                            </div>
                          </div>

                          <div className="pt-12 border-t border-indigo-500/10">
                            <h3 className="text-3xl font-black text-white italic mb-6">डेटा संप्रभुता और एआई नैतिकता</h3>
                            <p className="text-lg text-slate-400 leading-relaxed text-justify mb-8">
                              साइटगार्ड **शून्य-ट्रस्ट नीति (Zero-Trust Policy)** पर आधारित है।
                            </p>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-sm text-slate-500">
                               <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800">
                                  <p className="font-bold text-white uppercase mb-2">डेटा आइसोलेशन</p>
                                  <p>आपका कोड एआई मॉडल्स को प्रशिक्षण देने के लिए कभी उपयोग नहीं किया जाता। सत्र समाप्त होने के बाद, एआई से सभी ट्रांजिएंट डेटा हटा दिया जाता है।</p>
                               </div>
                               <div className="p-6 bg-slate-900 rounded-3xl border border-slate-800">
                                  <p className="font-bold text-white uppercase mb-2">कुंजी सुरक्षा</p>
                                  <p>आपकी एपीआई कुंजियाँ पूरी तरह से एन्क्रिप्टेड हैं और आपके ब्राउज़र के सुरक्षित लोकल स्टोरेज में रहती हैं।</p>
                               </div>
                            </div>
                          </div>
                        </div>
                      </section>

                      {/* Section 05: Setup Deep Dive */}
                      <section className="space-y-12">
                        <div className="flex items-center gap-4">
                          <div className="h-0.5 flex-1 bg-gradient-to-r from-emerald-500 to-transparent"></div>
                          <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest">अनुभाग 05</span>
                        </div>
                        <h2 className="text-4xl font-black text-white italic tracking-tight uppercase">V. परिचालन निष्पादन विवरण</h2>
                        <div className="space-y-8">
                           <div className="p-10 bg-slate-900/60 border border-slate-800 rounded-[3rem] space-y-6">
                              <h4 className="text-2xl font-bold text-white">1. गिटहब टोकन का महत्व</h4>
                              <p className="text-slate-400 leading-relaxed">
                                साइटगार्ड आपके रिपॉजिटरी में हाथ (virtual hand) की तरह काम करता है। बिना टोकन के, हम फाइलों को पढ़ने या शैडो ब्रांच बनाने में असमर्थ होंगे। ध्यान रहे कि टोकन में 'repo' स्कोप होना अनिवार्य है।
                              </p>
                           </div>
                           <div className="p-10 bg-slate-900/60 border border-slate-800 rounded-[3rem] space-y-6">
                              <h4 className="text-2xl font-bold text-white">2. ओपनराउटर का लाभ</h4>
                              <p className="text-slate-400 leading-relaxed">
                                हालांकि हम बुनियादी मॉडल प्रदान करते हैं, लेकिन गंभीर रिफैक्टरिंग के लिए **Claude 3.5 Sonnet** या **Gemini 1.5 Pro** जैसे मॉडल्स की आवश्यकता होती है, जो केवल एपीआई कुंजी के माध्यम से संभव है।
                              </p>
                           </div>
                        </div>
                      </section>

                      <footer className="pt-24 text-center space-y-4">
                        <div className="w-20 h-0.5 bg-slate-800 mx-auto"></div>
                        <p className="text-slate-600 text-[10px] font-mono tracking-widest uppercase">
                          अधिकृत दस्तावेज़ | साइटगार्ड सुरक्षा v3.0 | केवल आंतरिक उपयोग के लिए
                        </p>
                      </footer>
                    </article>
                  )}
                </div>
              </div>
            ) : mainView === 'legal' ? (
              <div className="max-w-4xl mx-auto space-y-12 px-4 md:px-0 pb-20">
                <section className="animate-in fade-in slide-in-from-bottom-8">
                  <h3 className="text-4xl font-black mb-8 flex items-center gap-4 italic uppercase tracking-tighter">
                    <Shield className="w-10 h-10 text-indigo-500" />
                    Privacy Protocol v1.2
                  </h3>
                  <div className="bg-slate-950/80 border border-slate-800/80 p-10 md:p-16 rounded-[4rem] text-lg text-slate-400 leading-relaxed shadow-2xl space-y-8">
                    <div>
                      <p className="font-black text-indigo-400 uppercase tracking-[0.3em] text-[10px] mb-4">I. Data Transmission</p>
                      <p className="text-justify">SiteGuard operates as a stateless orchestration layer. We do not store your source code on our servers. All code ingestion happens transiently during the repair cycle. Once the fix is generated and pushed to your specified GitHub repository, all intermediate data in the context window is purged from memory.</p>
                    </div>
                    <div>
                      <p className="font-black text-indigo-400 uppercase tracking-[0.3em] text-[10px] mb-4">II. Credential Management</p>
                      <p className="text-justify">Your API keys (GitHub PAT, OpenRouter/Gemini keys) are stored purely using industry-standard LocalStorage within your browser. They are never transmitted back to SiteGuard's central registry. They are encrypted at rest using your local browser environment's protection mechanisms.</p>
                    </div>
                    <div>
                      <p className="font-black text-indigo-400 uppercase tracking-[0.3em] text-[10px] mb-4">III. AI Interaction</p>
                      <p className="text-justify">By using this application, you acknowledge that your code snippets will be sent to third-party AI providers (Google, Anthropic via OpenRouter) for processing. We strongly recommend reviewing the privacy policies of these specific providers.</p>
                    </div>
                  </div>
                </section>

                <section className="animate-in fade-in slide-in-from-bottom-8 delay-150">
                  <h3 className="text-4xl font-black mb-8 flex items-center gap-4 italic uppercase tracking-tighter">
                    <FileText className="w-10 h-10 text-emerald-500" />
                    Operational License
                  </h3>
                  <div className="bg-slate-950/80 border border-slate-800/80 p-10 md:p-16 rounded-[4rem] text-lg text-slate-400 leading-relaxed shadow-2xl space-y-8">
                    <p className="text-justify">SiteGuard is provided as an open-source development aid. We do not guarantee 100% security coverage. AI models are prone to "hallucinations" and may generate code that contains errors. <strong>The user assumes all responsibility</strong> for merging machine-generated patches into production branches.</p>
                    <p className="text-justify italic border-l-4 border-emerald-500/20 pl-8 text-sm">SiteGuard shall not be liable for any downtime, data loss, or security breaches resulting from the misuse of this tool or the failure to properly audit AI-generated code changes.</p>
                    <div className="pt-8 flex flex-wrap gap-4">
                      <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-[10px] font-black uppercase text-slate-500 tracking-widest">MIT License Applied</div>
                      <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-[10px] font-black uppercase text-slate-500 tracking-widest">Enterprise Ready</div>
                      <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-[10px] font-black uppercase text-slate-500 tracking-widest">SOC2 Compliant Architecture</div>
                    </div>
                  </div>
                </section>
              </div>
            ) : (
              <div className="max-w-xl mx-auto space-y-8 py-8 md:py-12 px-4 md:px-0">
                <div className="text-center">
                  <Settings className="w-12 h-12 text-indigo-500 mx-auto mb-4" />
                  <h3 className="text-2xl font-bold">Global Configuration</h3>
                  <p className="text-slate-500 text-sm">Manage system-wide parameters and security.</p>
                </div>
                
                <div className="space-y-6 bg-slate-900/40 border border-slate-800 p-4 md:p-8 rounded-3xl">
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase text-slate-500 tracking-widest">Your OpenRouter API Key</label>
                    <input 
                      type="password" 
                      value={userOpenRouterKey}
                      onChange={(e) => {
                        const val = e.target.value;
                        setUserOpenRouterKey(val);
                        localStorage.setItem('user_openrouter_key', val);
                      }}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:border-indigo-500 transition-colors" 
                      placeholder="sk-or-v1-..." 
                    />
                    <p className="text-[10px] text-slate-500">Provide your own key to use custom models and avoid global limits. Stored safely in your browser.</p>
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase text-slate-500 tracking-widest">Master AI Model Override</label>
                    <input type="number" defaultValue="60" className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 outline-none" placeholder="Minutes" />
                  </div>
                  <div className="pt-4">
                    <button className="w-full bg-white text-black font-bold py-3 rounded-xl hover:bg-slate-200 transition-all">
                      Save Global Settings
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>

      {/* Site Management Modal */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className={`fixed bottom-8 left-1/2 -translate-x-1/2 z-[100] px-6 py-3 rounded-full shadow-2xl flex items-center gap-2 border ${toast.type === 'error' ? 'bg-rose-950/90 border-rose-500/50 text-rose-200' : 'bg-emerald-950/90 border-emerald-500/50 text-emerald-200'}`}
          >
            {toast.type === 'error' ? <AlertCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
            <span className="text-sm font-medium">{toast.message}</span>
          </motion.div>
        )}

        {deleteConfirmId && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/80 backdrop-blur-sm">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-sm w-full shadow-2xl text-center"
            >
              <div className="w-16 h-16 bg-rose-500/10 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-6">
                 <Trash2 className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold mb-2">Delete Website?</h3>
              <p className="text-slate-500 text-sm mb-8">This will remove the website from monitoring. This action cannot be undone.</p>
              <div className="flex gap-4">
                <button 
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 px-4 py-3 bg-slate-800 hover:bg-slate-700 rounded-xl font-bold transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={() => handleDeleteWebsite(deleteConfirmId)}
                  className="flex-1 px-4 py-3 bg-rose-600 hover:bg-rose-500 rounded-xl font-bold transition-all shadow-lg shadow-rose-600/20"
                >
                  Delete
                </button>
              </div>
            </motion.div>
          </div>
        )}

        {(showAddModal || showEditModal) && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4">
            <motion.div 
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-slate-900 border border-slate-800 w-full max-w-xl rounded-3xl overflow-hidden shadow-2xl"
            >
              <div className="p-8 border-b border-slate-800 bg-slate-900/50 flex justify-between items-center">
                <div>
                  <h3 className="text-2xl font-bold">{editingSite ? 'Edit Mission' : 'New Mission'}</h3>
                  <p className="text-sm text-slate-500">{editingSite ? 'Update parameters for this domain.' : 'Add a website to the monitoring perimeter.'}</p>
                </div>
                <button 
                  onClick={() => { setShowAddModal(false); setShowEditModal(false); }} 
                  className="p-2 hover:bg-slate-800 rounded-full transition-colors text-slate-400"
                >
                  <Plus className="w-6 h-6 rotate-45" />
                </button>
              </div>
              <form onSubmit={handleSaveWebsite} className="p-4 md:p-8 space-y-4 md:space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase text-slate-500 tracking-widest">Name</label>
                    <input 
                      required
                      value={siteForm.name}
                      onChange={e => setSiteForm({...siteForm, name: e.target.value})}
                      type="text" placeholder="My Awesome Project" 
                      className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:border-indigo-500 transition-colors"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase text-slate-500 tracking-widest">URL</label>
                    <input 
                      required
                      value={siteForm.url}
                      onChange={e => setSiteForm({...siteForm, url: e.target.value})}
                      type="url" placeholder="https://example.com" 
                      className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:border-indigo-500 transition-colors"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase text-slate-500 tracking-widest">GitHub Repo (owner/repo)</label>
                    <input 
                      required
                      value={siteForm.repo}
                      onChange={e => setSiteForm({...siteForm, repo: e.target.value})}
                      type="text" placeholder="facebook/react" 
                      className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:border-indigo-500 transition-colors"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-black uppercase text-slate-500 tracking-widest">Framework</label>
                    <select 
                      value={siteForm.framework}
                      onChange={e => setSiteForm({...siteForm, framework: e.target.value})}
                      className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:border-indigo-500 transition-colors appearance-none"
                    >
                      <option>React</option>
                      <option>Vite</option>
                      <option>Next.js</option>
                      <option>Express</option>
                      <option>Static</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-black uppercase text-slate-500 tracking-widest">GitHub Token {editingSite ? '(Updated)' : '(Secret)'}</label>
                  <input 
                    value={siteForm.githubToken}
                    onChange={e => setSiteForm({...siteForm, githubToken: e.target.value})}
                    type="password" placeholder="ghp_xxxxxxxxxxxx" 
                    className="w-full bg-slate-950/50 border border-slate-800 rounded-xl px-4 py-3 outline-none focus:border-indigo-500 transition-colors"
                  />
                  <p className="text-[10px] text-slate-600">Necessary for auto-fix pushes. Stored only on your server.</p>
                </div>
                <div className="pt-4">
                  <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-4 rounded-xl shadow-xl shadow-indigo-600/20 active:scale-[0.98] transition-all">
                    {editingSite ? 'Save Changes' : 'Initialize Monitoring'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      
      {/* Real-time Terminal Preview */}
      <AnimatePresence>
        {showTerminal && (
          <motion.div 
            initial={{ y: 300, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 300, opacity: 0 }}
            className="fixed bottom-0 right-0 w-full lg:w-[500px] z-[80] p-4"
          >
            <div className="bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[300px]">
              <div className="bg-slate-900 px-4 py-2 flex items-center justify-between border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-indigo-400" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Live Telemetry</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-mono text-indigo-500/50">siteguard_debug.log</span>
                  <button onClick={() => setShowTerminal(false)} className="text-slate-500 hover:text-white">
                    <Plus className="w-4 h-4 rotate-45" />
                  </button>
                </div>
              </div>
              <div className="flex-1 p-4 overflow-y-auto font-mono text-[11px] space-y-1 custom-scrollbar bg-black/50">
                {logs.slice(0, 30).reverse().map((log, i) => (
                  <div key={`term-${log.id}-${i}`} className="flex gap-3">
                    <span className="text-slate-700 select-none">[{new Date(log.timestamp).toLocaleTimeString([], { hour12: false })}]</span>
                    <span className={`
                      ${log.type === 'error' ? 'text-rose-500' : 
                        log.type === 'warning' ? 'text-amber-500' : 
                        log.type === 'success' ? 'text-emerald-500' : 
                        'text-indigo-400'}
                    `}>
                      {log.type === 'error' ? '✖' : log.type === 'success' ? '✔' : 'i'}
                    </span>
                    <span className="text-slate-300 break-words">{log.message}</span>
                  </div>
                ))}
                
                {aiPreview && (
                  <div className="my-4 border border-indigo-500/30 rounded-lg overflow-hidden">
                    <div className="bg-indigo-500/20 px-3 py-1 flex justify-between items-center bg-slate-900 border-b border-indigo-500/30">
                      <span className="text-[9px] text-indigo-300 font-bold uppercase tracking-widest">Diff Preview: {aiPreview.path}</span>
                    </div>
                    <pre className="p-3 text-[9px] text-emerald-400/90 whitespace-pre-wrap max-h-40 overflow-y-auto">
                      {aiPreview.content}
                    </pre>
                  </div>
                )}

                {projectPreview && (
                  <div className="my-4 space-y-2">
                    <div className="px-3 py-1 bg-indigo-500/20 border border-indigo-500/30 rounded-lg">
                      <span className="text-[9px] text-indigo-300 font-bold uppercase tracking-widest">Multi-File Update ({projectPreview.length} files)</span>
                    </div>
                    <div className="grid grid-cols-1 gap-1">
                      {projectPreview.map((f: any, idx: number) => (
                        <div key={idx} className="flex items-center gap-2 px-3 py-1 bg-slate-900 border border-slate-800 rounded-md">
                          <FileCode className="w-3 h-3 text-slate-500" />
                          <span className="text-[10px] text-slate-300 font-mono truncate">{f.path}</span>
                          <span className="ml-auto text-[8px] text-emerald-500/50 uppercase font-black">Modified</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {(isEditing || isGlobalEditing || scanning) && (
                  <div className="flex gap-2 items-center text-indigo-400">
                    <span className="animate-pulse">_</span>
                    <span className="animate-pulse">PROCESS_RUNNING</span>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #475569; }
      `}</style>
    </div>
  );
}
